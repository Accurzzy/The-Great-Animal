import discord
from discord.ext import commands
from functions import *  # Assuming these functions are properly imported
import mysql.connector

# Assuming animals dictionary from your data
animals = {
    "Buffalo": {"price": 25000, "image": "", "quantity": 0, "gender": ""},
    "Crocodille": {"price": 25000, "image": "", "quantity": 0, "gender": ""},
    "Eagle": {"price": 3000, "image": "", "quantity": 0, "gender": ""},
    "Elephant": {"price": 25000, "image": "", "quantity": 0, "gender": ""},
    "Gazelle": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Giraffe": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Hare": {"price": 100000, "image": "", "quantity": 0, "gender": ""},
    "Hippopotamus": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Hyena": {"price": 15000, "image": "", "quantity": 0, "gender": ""},
    "Kudu": {"price": 15000, "image": "", "quantity": 0, "gender": ""},
    "Leopard": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Lion": {"price": 30000, "image": "", "quantity": 0, "gender": ""},
    "Lionness": {"price": 25000, "image": "", "quantity": 0, "gender": ""},
    "Meerkat": {"price": 6000, "image": "", "quantity": 0, "gender": ""},
    "Rhinoceros": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Shoebill": {"price": 6000, "image": "", "quantity": 0, "gender": ""},
    "Vulture": {"price": 3000, "image": "", "quantity": 0, "gender": ""},
    "Warthog": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Wildebeast": {"price": 50000, "image": "", "quantity": 0, "gender": ""},
    "WildDog": {"price": 20000, "image": "", "quantity": 0, "gender": ""},
    "Zebra": {"price": 15000, "image": "", "quantity": 0, "gender": ""}
}

class shop(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="shop", description="Display Animal Shop", with_app_command=True)
    @commands.check(in_animal_shop)
    async def shop(self, ctx):
        db = mysql.connector.connect(
            host=os.getenv("DATABASE_HOST"),
    		user=os.getenv("DATABASE_USER"),
    		password=os.getenv("DATABASE_PW"),
    		database=os.getenv("DATABASE_NAME")
        )
        cursor = db.cursor()
        cursor.execute("SELECT bugs FROM players WHERE discord_id = %s", (ctx.author.id,))
        result = cursor.fetchone()
        if result is not None:
            current_balance = result[0]
        else:
            current_balance = 0

        # Get player's owned animals data
        owned_animals_data = get_player_animals(ctx.author.id)
        owned_animals = (
            "\n ".join(
                [
                    f"{animal.capitalize()} (x{data['quantity']})"
                    for animal, data in owned_animals_data.items()
                ]
            )
            print(type(owned_animals_data), owned_animals_data)
            if owned_animals_data
            else ""
        )

        # Shop message
        shop_message = "Available animals for purchase:\n"
        for animal, data in animals.items():
            price = data["price"]
            image = data["image"]
            # Age and Gender placeholders, replace with your actual data
            age_info = "Ages: Baby, Juvenile, SubAdult, Adult"
            gender_info = "Genders: Male, Female"
            
            shop_message += f"{image} {animal}: {price} :bug:\n{age_info}\n{gender_info}\n"

        # Combine the shop message and ephemeral Note embed
        combined_embed = discord.Embed(
            title="Animalia Survival Shop 🏪", description=shop_message, color=0xf1c40f
        )
        combined_embed.add_field(name="Your bugs", value=f":bug:`{current_balance}`", inline=False)

        if owned_animals:
            combined_embed.add_field(name="Your owned animals", value=owned_animals, inline=False)

        # Send the combined embed with the ephemeral Note
        await ctx.send(embed=combined_embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(shop(bot))