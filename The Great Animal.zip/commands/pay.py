from functions import *
from import_lib import *
import datetime
import mysql.connector
import os
import requests
import discord
from discord.ext import commands

webhook_env = os.getenv("PAY_WEBHOOK")

def log_transaction(sender_id, recipient_id, amount, sender_name, recipient_name):
    """Log the transaction to a local file."""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"{timestamp} - {sender_name} ({sender_id}) paid {recipient_name} ({recipient_id}) {amount} bugs\n"

    with open("transaction_log.txt", "a") as log_file:
        log_file.write(log_entry)


def send_to_webhook(sender_id, recipient_id, amount, sender_name, recipient_name):
    """Send the transaction details to a Discord webhook."""
    webhook_url = webhook_env
    if not webhook_url:
        print("DEBUG: Webhook URL not set.")
        return

    embed = {
        "title": "Transaction Log",
        "color": 0x00FF00,
        "fields": [
            {"name": "Sender", "value": f"{sender_name} ({sender_id})", "inline": True},
            {"name": "Recipient", "value": f"{recipient_name} ({recipient_id})", "inline": True},
            {"name": "Amount", "value": f"{amount} bugs", "inline": True},
        ],
        "timestamp": datetime.datetime.now().isoformat(),
    }

    payload = {"embeds": [embed], "username": "Transaction Logger"}

    try:
        response = requests.post(webhook_url, json=payload)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"DEBUG: Webhook error: {e}")


class Pay(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="pay", description="Pay bugs to another user", with_app_command=True)
    async def pay(self, ctx, member: discord.Member, amount: int):
        """
        Pay bugs to a user.

        :param ctx: Context of the command.
        :param member: The user you want to make the payment to.
        :param amount: The amount of bugs to send.
        """
        try:
            # Prevent self-payment
            if member == ctx.author:
                await ctx.send(embed=discord.Embed(
                    title="Animalia Survival 🤖",
                    description="You cannot pay yourself.",
                    color=0xFF0000,
                ))
                return

            # Validate amount
            if amount <= 0:
                await ctx.send(embed=discord.Embed(
                    title="Animalia Survival 🤖",
                    description="The amount must be greater than 0.",
                    color=0xFF0000,
                ))
                return

            # Database connection
            db = mysql.connector.connect(
                host=os.getenv("DATABASE_HOST"),
                user=os.getenv("DATABASE_USER"),
                password=os.getenv("DATABASE_PW"),
                database=os.getenv("DATABASE_NAME"),
            )
            cursor = db.cursor()

            # Check sender's balance
            cursor.execute("SELECT bugs FROM players WHERE discord_id = %s", (ctx.author.id,))
            sender_data = cursor.fetchone()
            if not sender_data or sender_data[0] < amount:
                await ctx.send(embed=discord.Embed(
                    title="Animalia Survival 🤖",
                    description="You do not have enough bugs to complete this transaction.",
                    color=0xFF0000,
                ))
                return

            # Check recipient exists
            cursor.execute("SELECT bugs FROM players WHERE discord_id = %s", (member.id,))
            recipient_data = cursor.fetchone()
            if not recipient_data:
                await ctx.send(embed=discord.Embed(
                    title="Animalia Survival 🤖",
                    description=f"{member.mention} is not registered in the database.",
                    color=0xFF0000,
                ))
                return

            # Perform transaction
            cursor.execute("UPDATE players SET bugs = bugs - %s WHERE discord_id = %s", (amount, ctx.author.id))
            cursor.execute("UPDATE players SET bugs = bugs + %s WHERE discord_id = %s", (amount, member.id))
            db.commit()

            # Log transaction
            log_transaction(ctx.author.id, member.id, amount, ctx.author.name, member.name)
            send_to_webhook(ctx.author.id, member.id, amount, ctx.author.name, member.name)

            # Confirm transaction
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description=f"{ctx.author.mention} paid {member.mention} {amount} bugs.",
                color=0x00FF00,
            ))

        except mysql.connector.Error as e:
            print(f"DEBUG: Database error: {e}")
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description=f"Database error occurred: {e}",
                color=0xFF0000,
            ))
        except Exception as e:
            print(f"DEBUG: Unexpected error: {e}")
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description=f"An unexpected error occurred: {e}",
                color=0xFF0000,
            ))
        finally:
            if db.is_connected():
                cursor.close()
                db.close()

    @pay.error
    async def pay_error(self, ctx, error):
        """Handle errors for the /pay command."""
        if isinstance(error, commands.BadArgument):
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description="Please mention a valid user.",
                color=0xFF0000,
            ))
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description="Please use the command correctly: `/pay <user> <amount>`",
                color=0xFF0000,
            ))
        else:
            await ctx.send(embed=discord.Embed(
                title="Animalia Survival 🤖",
                description=f"An error occurred: {error}",
                color=0xFF0000,
            ))


async def setup(bot):
    await bot.add_cog(Pay(bot))
