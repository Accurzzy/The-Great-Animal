import discord
from discord.ext import commands
from discord import app_commands
import json
import mysql.connector
import os
from dotenv import load_dotenv
from functions import get_player_data, save_player_data, animals, in_animal_shop

# Load environment variables from .env file
load_dotenv()

# Database configuration using environment variables
config = {
    "user": os.getenv("DATABASE_USER"),
    "password": os.getenv("DATABASE_PW"),
    "host": os.getenv("DATABASE_HOST"),
    "database": os.getenv("DATABASE_NAME"),
}

class Buy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Autocomplete function for animals
    async def animal_autocomplete(self, ctx, current: str):
        suggestions = [animal for animal in animals.keys() if current.lower() in animal.lower()]
        return [app_commands.Choice(name=animal, value=animal) for animal in suggestions]

    # Autocomplete function for gender
    async def gender_autocomplete(self, ctx, current: str):
        genders = ['Male', 'Female']
        return [app_commands.Choice(name=gender, value=gender) for gender in genders if current.lower() in gender.lower()]

    # Autocomplete function for ages
    async def ages_autocomplete(self, ctx, current: str):
        ages = ['Baby', 'Juvenile', 'SubAdult', 'Adult']
        return [app_commands.Choice(name=age, value=age) for age in ages if current.lower() in age.lower()]

    @commands.check(in_animal_shop)  # Make sure the user is in the correct channel
    @commands.hybrid_command(name="buy", description="Buy Animals from the shop", with_app_command=True)
    @app_commands.autocomplete(animal=animal_autocomplete)  # Autocomplete for animal names
    @app_commands.autocomplete(gender=gender_autocomplete)  # Autocomplete for gender
    @app_commands.autocomplete(ages=ages_autocomplete)  # Autocomplete for ages
    async def buy(self, ctx, animal=None, gender=None, ages=None):
        """
        Buy Animals from the shop and add them to the player's cage.

        :param animal: The animal to buy.
        :param age: The age of the animal.
        :param gender: The gender of the animal.
        """
        # Get player data from the database
        player_data = get_player_data(ctx.author.id)

        # Debugging: Log player data to see if it's correct
        print(f"Player Data for {ctx.author.id}: {player_data}")

        # Check if the player has linked their Steam ID
        if player_data is None or player_data.get("steam_id") is None:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description=f"{ctx.author.mention}, you need to link your Steam ID first using the !link command.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Ensure the animal is specified
        if animal is None:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description="You need to specify an animal to buy.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Ensure the age is specified
        if ages is None:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description="You need to specify an age to buy.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Ensure the gender is specified
        if gender is None:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description="You need to specify a gender to buy.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Check if the animal exists
        if animal not in animals:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description=f"{ctx.author.mention}, that animal does not exist.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Get the animal price and check if the player has enough bugs
        animal_data = animals[animal]
        price = round(float(animal_data["price"]))  # Convert price to float and round
        player_bugs = player_data.get("bugs", 0)

        if player_bugs < price:
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description=f"{ctx.author.mention}, you don't have enough bugs to buy this animal.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)
            return

        # Deduct the cost of the animal from the player's balance
        new_balance = player_bugs - price

        try:
            # Connect to the database and update bugs
            with mysql.connector.connect(**config) as db:
                with db.cursor() as cursor:
                    cursor.execute(
                        "UPDATE players SET bugs = %s WHERE discord_id = %s",
                        (new_balance, ctx.author.id),
                    )
                    db.commit()

            # Update the player's data with the new balance
            player_data["bugs"] = new_balance

            # Check if 'animals' field exists in the database
            if 'animals' not in player_data:
                print(f"Initializing 'animals' field for {ctx.author.id}...")
                player_data['animals'] = "{}"  # Initialize 'animals' if missing

            # Load player animals data
            try:
                # Ensure the animals field is loaded as a string and parsed correctly
                player_animals = json.loads(player_data['animals']) if isinstance(player_data['animals'], str) else {}
            except json.JSONDecodeError:
                print(f"Error decoding 'animals' field for {ctx.author.id}. Initializing empty animals.")
                player_animals = {}

            # Debugging: Log the animals data
            print(f"Player Animals Data for {ctx.author.id}: {player_animals}")

            # Add the animal to the player's collection
            if animal not in player_animals:
                player_animals[animal] = {
                    "name": animal,
                    "price": price,
                    "quantity": 1,
                    "ages": [{"ages": ages, "quantity": 1}],
                    "genders": [{"gender": gender, "quantity": 1}],
                    "cage": True  # Mark as caged after purchase
                }
            else:
                player_animals[animal]["quantity"] += 1
                # Add age
                age_exists = False
                for age_data in player_animals[animal]["ages"]:
                    if age_data["ages"] == ages:
                        age_data["quantity"] += 1
                        age_exists = True
                        break
                if not age_exists:
                    player_animals[animal]["ages"].append({"ages": ages, "quantity": 1})

                # Add gender
                gender_exists = False
                for gender_data in player_animals[animal]["genders"]:
                    if gender_data["gender"] == gender:
                        gender_data["quantity"] += 1
                        gender_exists = True
                        break
                if not gender_exists:
                    player_animals[animal]["genders"].append({"gender": gender, "quantity": 1})

            # Save the updated animal data back to the database
            try:
                # Convert the `player_animals` dictionary to a JSON string before saving to the database
                player_animals_json = json.dumps(player_animals)
                
                # Connect to the database and update the 'animals' field
                with mysql.connector.connect(**config) as db:
                    with db.cursor() as cursor:
                        cursor.execute(
                            "UPDATE players SET animals = %s WHERE discord_id = %s",
                            (player_animals_json, ctx.author.id),  # Pass JSON string
                        )
                        db.commit()
            except Exception as e:
                print(f"Error updating database for {ctx.author.id}: {e}")

            # Provide the user with feedback
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description=f"{ctx.author.mention}, You have bought a {ages} {gender} {animal} for {price} bugs. Your remaining balance: {new_balance} bugs.",
                color=0x00FF00,
            )
            await ctx.send(embed=embed)

        except mysql.connector.Error as e:
            print(f"Database error: {e}")
            embed = discord.Embed(
                title="Animalia Survival 🤖",
                description=f"An error occurred while processing your request. Please try again later.",
                color=0xFF0000,
            )
            await ctx.send(embed=embed)

# Add the Buy Cog to the bot
async def setup(bot):
    await bot.add_cog(Buy(bot))