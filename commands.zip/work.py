from functions import *
from import_lib import *
from datetime import datetime, timedelta
import mysql.connector
import os
import random
import discord
from discord.ext import commands

class work(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="work", description="Get bugs!", with_app_command=True)
    @commands.check(in_animal_shop)
    async def work(self, ctx):
        try:
            player_data = get_player_data(ctx.author.id)

            # Check if the player has linked their Steam ID
            if player_data is None or player_data["steam_id"] is None:
                embed = discord.Embed(
                    title="Animalia Survival 🤖",
                    description=f"{ctx.author.mention}, you need to link your Steam ID first using the !link command.",
                    color=0xFF0000,
                )
                await ctx.send(embed=embed)
                return

            # Ensure the database schema is correct
            self.ensure_last_work_time_column()

            # Get the last_work_time from the player's data
            last_work_time = player_data.get("last_work_time") or datetime.min
            current_time = datetime.now()

            # Calculate the time difference
            time_difference = current_time - last_work_time

            if time_difference >= timedelta(hours=1):
                # Generate a random amount of bugs between 500-2000
                bugs_earned = random.randint(350, 1250)

                # Update the user's balance in the database
                db = self.get_database_connection()
                cursor = db.cursor()

                # Fetch current balance
                cursor.execute("SELECT bugs FROM players WHERE discord_id = %s", (ctx.author.id,))
                result = cursor.fetchone()
                current_balance = result[0] if result else 0
                new_balance = current_balance + bugs_earned

                # Update the player's data in the database, including last_work_time
                cursor.execute(
                    "UPDATE players SET bugs = %s, last_work_time = %s WHERE discord_id = %s",
                    (new_balance, current_time, ctx.author.id),
                )
                db.commit()

                # Send the command response with the updated user data
                embed = discord.Embed(
                    title="Animalia Survival 🤖",
                    description=f"You earned {bugs_earned} :bug:! Your new balance is {new_balance} :bug:.",
                    color=0x00FF00,
                )
                embed.set_footer(text=f"Total bugs earned: {new_balance} bugs")
                await ctx.send(embed=embed)
            else:
                # Calculate the remaining cooldown time in hours and minutes
                remaining_cooldown = timedelta(hours=1) - time_difference
                hours, seconds = divmod(remaining_cooldown.total_seconds(), 3600)
                minutes = seconds // 60
                embed = discord.Embed(
                    title="Animalia Survival 🤖",
                    description=f"You can use this command again in {int(hours)} hours and {int(minutes)} minutes.",
                    color=0xFF0000,
                )
                await ctx.send(embed=embed)

            # Debug logs
            print(f"DEBUG: last_work_time: {last_work_time}")
            print(f"DEBUG: current_time: {current_time}")
            print(f"DEBUG: Difference: {time_difference}")
            print(f"DEBUG: Is cooldown reached? {time_difference >= timedelta(hours=1)}")

        except mysql.connector.Error as e:
            print(f"DEBUG: Error during database update: {e}")
            await ctx.send(f"An error occurred while updating the database: {e}")
        except Exception as e:
            print(f"DEBUG: Unexpected error: {e}")
            await ctx.send(f"An unexpected error occurred: {e}")

    def ensure_last_work_time_column(self):
        """Ensure the `last_work_time` column exists in the `players` table."""
        try:
            db = self.get_database_connection()
            cursor = db.cursor()
            cursor.execute(
                """
                ALTER TABLE players
                ADD COLUMN IF NOT EXISTS last_work_time datetime DEFAULT NULL
                """
            )
            db.commit()
            print("DEBUG: Ensured last_work_time column exists in players table.")
        except mysql.connector.Error as e:
            print(f"DEBUG: Error ensuring last_work_time column: {e}")
            raise e

    def get_database_connection(self):
        """Helper function to connect to the database."""
        return mysql.connector.connect(
            host=os.getenv("DATABASE_HOST"),
            user=os.getenv("DATABASE_USER"),
            password=os.getenv("DATABASE_PW"),
            database=os.getenv("DATABASE_NAME"),
        )

async def setup(bot):
    await bot.add_cog(work(bot))
